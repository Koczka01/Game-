import tkinter as tk
from PIL import Image, ImageTk, ImageOps
import csv
import random
import os

SOUND_ON = True
SFX_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sfx")

SFX = {
    "start": "start.wav",
    "jump": "jump.wav",
    "double": "double.wav",
    "coin": "coin.wav",
    "onion": "powerup.wav",
    "stomp": "stomp.wav",
    "boss": "vine_boom.wav",
    "hit": "vine_boom.wav",
    "checkpoint": "checkpoint.wav",
    "win": "win.wav",
    "over": "over.wav",
}

_sounds = {}
_audio_ok = False
try:
    os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
    import pygame
    pygame.mixer.pre_init(44100, -16, 1, 512)
    pygame.mixer.init()
    pygame.mixer.set_num_channels(24)
    _audio_ok = True
except Exception:
    _audio_ok = False


def play_sfx(name):
    if not SOUND_ON or not name:
        return
    if _audio_ok:
        try:
            snd = _sounds.get(name)
            if snd is None and name not in _sounds:
                try:
                    snd = pygame.mixer.Sound(os.path.join(SFX_DIR, name))
                except Exception:
                    snd = None
                _sounds[name] = snd
            if snd is not None:
                snd.play()
            return
        except Exception:
            pass
    try:
        import winsound
        winsound.PlaySound(os.path.join(SFX_DIR, name),
                           winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception:
        pass

MEME_STOMP = ["BONK!", "POW!", "OOF", "GET REKT", "L + RATIO", "SKIBIDI", "NO CAP",
              "GYATT", "SHEEEESH", "+RIZZ", "DELETED", "404 NPC"]
MEME_COIN = ["+CASH", "BUSSIN", "W", "CHA-CHING", "STONKS", "FANUM TAX", "GYATT$"]
MEME_JUMP = ["BOING", "YEET", "WHEE", "SIGMA JUMP", "HOPS"]
MEME_AIR = ["AIR RIZZ", "MEWING", "GRAVITY WHO?", "DOUBLE SIGMA"]
MEME_HIT = ["BRUH", "SKILL ISSUE", "OHIO MOMENT", "RIP BOZO", "L", "NPC DEATH",
            "-1 RIZZ", "GET ATARASHII'D", "CAUGHT IN 4K"]
MEME_CP = ["W CHECKPOINT", "SAVED!", "SIGMA SAVE", "RIZZ SECURED"]
MEME_TAUNT = ["only in ohio", "skibidi toilet", "what the sigma", "it's giving...",
              "he's cooked", "gyatt damn", "caught lacking", "0 aura", "max rizz",
              "mewing streak", "fanum tax due", "bro is edging on grass"]
BILLBOARDS = ["WELCOME TO OHIO", "SKIBIDI 5KM", "RIZZ STATION", "FANUM TAX AHEAD",
              "GYATT CANYON", "MEWING ZONE", "SIGMA HIGHWAY", "BRAINROT BLVD",
              "NO MAIDENS PARK", "OHIO FINAL BOSS >>"]
RANKS = [(35, "OHIO OVERLORD", "#ff3df0"), (24, "GIGACHAD", "#ff5252"),
         (16, "SIGMA", "#ffd24a"), (9, "CRACKED", "#76d275"), (4, "BUSSIN", "#a8c0ff")]
COMBO_TIME = 150
MEME_FONT = "Arial Black"

W, H = 1000, 620
CENTER_X = 500
GROUND_Y = 470
GRAVITY = 0.8
JUMP_V = -15.0
MOVE_SPEED = 9
WORLD_END = 50000
COYOTE = 6
JUMP_BUFFER = 7
MAX_LIVES = 3

ENEMY_FILES = {
    "grunt": "goofy_ahhh_enemy.jpg",
    "elite": "goofy_ahh_harder_enemy_for_the_game.gif",
}
PLAYER_FILE = "images.jpg"
ONION_FILE = "sonion.gif"
DEAD_FILE = "goofy_ah_dead_scene.gif"
BOSS_FILE = "goofy_ahh_boss_fight.jpg"


def lerp(a, b, t):
    return tuple(int(x + (y - x) * t) for x, y in zip(a, b))


def hexc(c):
    return "#%02x%02x%02x" % c


def round_rect(canvas, x1, y1, x2, y2, r, **kw):
    pts = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return canvas.create_polygon(pts, smooth=True, **kw)


class Game:
    def __init__(self, root):
        self.root = root
        root.title("GOOFY RUN - Definitive Edition")
        root.resizable(False, False)
        self.canvas = tk.Canvas(root, width=W, height=H, bg="#1e2746", highlightthickness=0)
        self.canvas.pack()
        c = self.canvas

        self.keep = []
        self.tick = 0
        self.kamera_x = 0.0
        self.layers = []
        self.particles = []
        self.floaters = []
        self.enemy_by_id = {}
        self.coin_by_id = {}
        self.checkpoints = []
        self.last_checkpoint = 0.0

        self.combo = 0
        self.combo_timer = 0
        self.best_combo = 0
        self.shake_t = 0
        self.shake_mag = 0.0
        self.shake_applied = [0.0, 0.0]
        self.hitstop = 0
        self.taunt_timer = 120

        self._load_assets()
        self._load_level()
        self._build_background()
        self._build_world()
        self._build_player()
        self._build_hud()

        self.state = "menu"
        self.lives = MAX_LIVES
        self.score = 0
        self.vy = 0.0
        self.on_ground = False
        self.jumps_left = 0
        self.coyote = 0
        self.jump_buf = 0
        self.facing = 1
        self.dead_idx = 0
        self.dead_timer = 0

        self.keys = {"a": False, "d": False}
        root.bind("<KeyPress>", self._key_down)
        root.bind("<KeyRelease>", self._key_up)
        root.bind("<space>", self._press_space)
        root.bind("<p>", lambda e: self._toggle_pause())
        root.bind("<r>", lambda e: self._restart_all())

        self._show_menu()
        self._loop()

    def _static(self, path, target_h, mirror=False):
        im = Image.open(path).convert("RGBA")
        if mirror:
            im = ImageOps.mirror(im)
        w, h = im.size
        tw = max(1, int(w * target_h / h))
        im = im.resize((tw, target_h), Image.LANCZOS)
        ph = ImageTk.PhotoImage(im)
        self.keep.append(ph)
        return ph

    def _frames(self, path, target_h):
        im = Image.open(path)
        out = []
        i = 0
        try:
            while True:
                im.seek(i)
                fr = im.convert("RGBA")
                w, h = fr.size
                tw = max(1, int(w * target_h / h))
                fr = fr.resize((tw, target_h), Image.LANCZOS)
                ph = ImageTk.PhotoImage(fr)
                self.keep.append(ph)
                out.append(ph)
                i += 1
        except EOFError:
            pass
        return out or [self._static(path, target_h)]

    def _load_assets(self):
        try:
            self.img_player_r = self._static(PLAYER_FILE, 78)
            self.img_player_l = self._static(PLAYER_FILE, 78, mirror=True)
        except Exception:
            self.img_player_r = self.img_player_l = None
        try:
            self.img_grunt = self._static(ENEMY_FILES["grunt"], 56)
        except Exception:
            self.img_grunt = None
        try:
            self.frames_elite = self._frames(ENEMY_FILES["elite"], 64)
        except Exception:
            self.frames_elite = []
        try:
            self.frames_onion = self._frames(ONION_FILE, 46)
        except Exception:
            self.frames_onion = []
        try:
            self.frames_dead = self._frames(DEAD_FILE, 190)
        except Exception:
            self.frames_dead = []
        try:
            self.img_boss = self._static(BOSS_FILE, 170)
        except Exception:
            self.img_boss = None

    def _load_level(self):
        self.segments = []
        try:
            with open("akadaly.csv", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    self.segments.append((int(row["start"]), int(row["end"])))
        except FileNotFoundError:
            self.segments = [(-2000, 1200), (1400, 5000)]

    def _new_layer(self, tag, factor):
        self.layers.append({"tag": tag, "factor": factor, "applied": 0.0})

    def _build_background(self):
        c = self.canvas
        top = (40, 58, 120)
        bottom = (255, 196, 150)
        bands = 60
        for i in range(bands):
            t = i / (bands - 1)
            y1 = int(H * i / bands)
            y2 = int(H * (i + 1) / bands)
            c.create_rectangle(0, y1, W, y2 + 1, fill=hexc(lerp(top, bottom, t)), outline="")
        c.create_oval(740, 60, 900, 220, fill="#ffe7b0", outline="")
        c.create_oval(770, 90, 870, 190, fill="#fff4d6", outline="")

        self._new_layer("hills", 0.18)
        hill_colors = ["#6a7fb5", "#7d93c4"]
        for k, col in enumerate(hill_colors):
            base = GROUND_Y + 60 + k * 30
            x = -2500
            while x < 54000:
                r = random.randint(280, 520)
                c.create_oval(x, base - r, x + r * 2, base + r, fill=col, outline="", tags="hills")
                x += r + random.randint(40, 160)

        self._new_layer("cloud_far", 0.35)
        self._new_layer("cloud_near", 0.62)
        for tag, ymax, count in (("cloud_far", 230, 70), ("cloud_near", 150, 45)):
            for i in range(count):
                cx = random.randint(-1000, 54000)
                cy = random.randint(30, ymax)
                s = random.randint(60, 130)
                col = "#ffffff" if tag == "cloud_near" else "#dfe8fb"
                c.create_oval(cx, cy, cx + s * 2, cy + s, fill=col, outline="", tags=tag)
                c.create_oval(cx + s // 2, cy - s // 3, cx + int(s * 2.2), cy + int(s * 0.7),
                              fill=col, outline="", tags=tag)

        self._new_layer("world", 1.0)

    def _build_world(self):
        c = self.canvas
        for start, end in self.segments:
            c.create_rectangle(start, GROUND_Y + 16, end, H + 200, fill="#6b4a2b", outline="", tags="world")
            c.create_rectangle(start, GROUND_Y, end, GROUND_Y + 18, fill="#4caf50", outline="", tags="world")
            c.create_rectangle(start, GROUND_Y, end, GROUND_Y + 5, fill="#76d275", outline="", tags="world")

        for cx in (8000, 16000, 24000, 32000, 40000):
            seg = self._segment_at(cx)
            if not seg:
                continue
            c.create_rectangle(cx - 3, GROUND_Y - 90, cx + 3, GROUND_Y, fill="#cfd8dc", outline="", tags="world")
            c.create_polygon(cx + 3, GROUND_Y - 90, cx + 55, GROUND_Y - 72, cx + 3, GROUND_Y - 54,
                             fill="#ff5252", outline="", tags=("world", "flag", "cp%d" % cx))
            self.checkpoints.append(cx)

        coins = 0
        for start, end in self.segments:
            x = max(start, 1500) + 200
            while x < end - 120 and coins < 90:
                if random.random() < 0.45:
                    cy = GROUND_Y - random.randint(70, 150)
                    cid = c.create_oval(x - 11, cy - 11, x + 11, cy + 11,
                                        fill="#ffd24a", outline="#caa01f", width=2, tags=("world", "coin"))
                    c.create_oval(x - 4, cy - 7, x + 1, cy + 2, fill="#fff0b8", outline="", tags=("world", "coin"))
                    self.coin_by_id[cid] = {"x": x, "y": cy, "value": 1, "kind": "coin"}
                    coins += 1
                x += random.randint(150, 320)

        if self.frames_onion:
            for _ in range(6):
                seg = random.choice(self.segments[3:])
                ox = random.randint(seg[0] + 60, max(seg[0] + 61, seg[1] - 60))
                oy = GROUND_Y - random.randint(90, 160)
                oid = c.create_image(ox, oy, image=self.frames_onion[0], tags=("world", "onion"))
                self.coin_by_id[oid] = {"x": ox, "y": oy, "value": 5, "kind": "onion", "fi": 0}

        for i, text in enumerate(BILLBOARDS):
            bx = 3000 + i * 4600 + random.randint(-300, 300)
            by = GROUND_Y - 170
            c.create_rectangle(bx - 4, by, bx + 4, GROUND_Y, fill="#5d4037", outline="", tags="world")
            c.create_rectangle(bx + 100 - 4, by, bx + 100 + 4, GROUND_Y, fill="#5d4037", outline="", tags="world")
            round_rect(c, bx - 95, by - 55, bx + 195, by + 8, 10, fill="#222b45", outline="#ffd24a",
                       width=3, tags="world")
            c.create_text(bx + 50, by - 24, text=text, fill="#ffd24a",
                          font=(MEME_FONT, 13), width=270, tags="world")

        self._build_enemies()

        gx = WORLD_END - 200
        c.create_rectangle(gx, GROUND_Y - 140, gx + 8, GROUND_Y, fill="#37474f", outline="", tags="world")
        c.create_rectangle(gx + 8, GROUND_Y - 140, gx + 80, GROUND_Y - 90,
                           fill="#ffeb3b", outline="#000", tags="world")
        c.create_text(gx + 44, GROUND_Y - 115, text="END", font=("Consolas", 16, "bold"), tags="world")

    def _build_enemies(self):
        c = self.canvas
        placed = 0
        attempts = 0
        while placed < 55 and attempts < 4000:
            attempts += 1
            wx = random.randint(1800, WORLD_END - 1500)
            seg = self._segment_at(wx)
            if not seg:
                continue
            roll = random.random()
            if roll < 0.62 and self.img_grunt:
                eid = c.create_image(wx, GROUND_Y - 28, image=self.img_grunt, tags=("world", "enemy"))
                data = {"id": eid, "type": "grunt", "hp": 1, "fi": 0, "frames": None}
            elif self.frames_elite:
                ey = GROUND_Y - random.randint(40, 150)
                eid = c.create_image(wx, ey, image=self.frames_elite[0], tags=("world", "enemy"))
                data = {"id": eid, "type": "elite", "hp": 1, "fi": 0, "frames": self.frames_elite}
            else:
                continue
            data.update({
                "wx": float(wx),
                "home": float(wx),
                "range": random.randint(140, 340),
                "spd": random.choice([-4, -3, 3, 4]),
            })
            self.enemy_by_id[eid] = data
            placed += 1

        if self.img_boss:
            bx = WORLD_END - 700
            seg = self._segment_at(bx) or self.segments[-1]
            bx = min(max(bx, seg[0] + 100), seg[1] - 100)
            bid = c.create_image(bx, GROUND_Y - 85, image=self.img_boss, tags=("world", "enemy", "boss"))
            self.enemy_by_id[bid] = {
                "id": bid, "type": "boss", "hp": 3, "fi": 0, "frames": None,
                "wx": float(bx), "home": float(bx), "range": 220, "spd": 3,
            }

    def _build_player(self):
        c = self.canvas
        if self.img_player_r:
            self.shadow = c.create_oval(CENTER_X - 28, GROUND_Y + 6, CENTER_X + 28, GROUND_Y + 22,
                                        fill="#000000", stipple="gray25", outline="")
            self.player = c.create_image(CENTER_X, GROUND_Y - 39, image=self.img_player_r)
        else:
            self.shadow = c.create_oval(CENTER_X - 24, GROUND_Y + 6, CENTER_X + 24, GROUND_Y + 20,
                                        fill="#000000", stipple="gray25", outline="")
            self.player = c.create_rectangle(CENTER_X - 22, GROUND_Y - 60, CENTER_X + 22, GROUND_Y,
                                             fill="#ff5252", outline="")

    def _build_hud(self):
        c = self.canvas
        c.create_rectangle(0, 0, W, 70, fill="#05070f", stipple="gray25", outline="", tags="vig")
        c.create_rectangle(0, H - 60, W, H, fill="#05070f", stipple="gray25", outline="", tags="vig")

        round_rect(c, 16, 14, 250, 64, 16, fill="#101626", stipple="gray50", outline="", tags="hud")
        round_rect(c, 16, 14, 250, 64, 16, fill="", outline="#2b3a63", width=2, tags="hud")
        self.hearts = []
        for i in range(MAX_LIVES):
            hx = 44 + i * 40
            ids = self._draw_heart(hx, 39, 12, "#ff4d6d")
            self.hearts.append(ids)

        round_rect(c, W - 290, 14, W - 16, 64, 16, fill="#101626", stipple="gray50", outline="", tags="hud")
        round_rect(c, W - 290, 14, W - 16, 64, 16, fill="", outline="#2b3a63", width=2, tags="hud")
        self.txt_score = c.create_text(W - 270, 30, anchor="w", text="SCORE 0",
                                       font=("Consolas", 14, "bold"), fill="#ffd24a", tags="hud")
        self.txt_dist = c.create_text(W - 270, 50, anchor="w", text="0 m",
                                      font=("Consolas", 13, "bold"), fill="#a8c0ff", tags="hud")

        self.txt_combo = c.create_text(W / 2, 40, text="", font=(MEME_FONT, 20),
                                       fill="#ffd24a", tags="hud")
        self.txt_rank = c.create_text(W / 2, 66, text="", font=(MEME_FONT, 14),
                                      fill="#ff5252", tags="hud")

    def _draw_heart(self, x, y, s, col):
        c = self.canvas
        ids = []
        ids.append(c.create_oval(x - s, y - s, x, y, fill=col, outline="", tags="hud"))
        ids.append(c.create_oval(x, y - s, x + s, y, fill=col, outline="", tags="hud"))
        ids.append(c.create_polygon(x - s, y - s * 0.35, x + s, y - s * 0.35, x, y + s,
                                    fill=col, outline="", tags="hud"))
        return ids

    def _update_hud(self):
        c = self.canvas
        for i, ids in enumerate(self.hearts):
            col = "#ff4d6d" if i < self.lives else "#39405c"
            for _id in ids:
                c.itemconfig(_id, fill=col)
        c.itemconfig(self.txt_score, text="SCORE %d" % self.score)
        c.itemconfig(self.txt_dist, text="%d m" % max(0, int(self.kamera_x / 10)))

        if self.combo >= 2:
            mult = self._mult()
            pulse = "#ffd24a" if (self.tick // 4) % 2 == 0 else "#fff4d6"
            c.itemconfig(self.txt_combo, text="COMBO x%d  (x%d)" % (self.combo, mult), fill=pulse)
            name, col = self._rank()
            c.itemconfig(self.txt_rank, text=name or "", fill=col or "#ff5252")
        else:
            c.itemconfig(self.txt_combo, text="")
            c.itemconfig(self.txt_rank, text="")

        c.tag_raise("vig")
        c.tag_raise("hud")

    def _clear_overlay(self):
        self.canvas.delete("overlay")

    def _dim(self, alpha="gray50"):
        self.canvas.create_rectangle(0, 0, W, H, fill="#05070f", stipple=alpha, outline="", tags="overlay")

    def _otext(self, x, y, text, size, color, anchor="center", font="Consolas", style="bold"):
        return self.canvas.create_text(x, y, text=text, font=(font, size, style),
                                       fill=color, anchor=anchor, tags="overlay")

    def _show_menu(self):
        self._clear_overlay()
        self._dim("gray50")
        self.canvas.create_text(W / 2 + 4, 154, text="GOOFY RUN", font=(MEME_FONT, 64),
                                fill="#0a0c14", tags="overlay")
        self._otext(W / 2, 150, "GOOFY RUN", 64, "#ffd24a", font=MEME_FONT)
        self.menu_sub = self._otext(W / 2, 212, "BRAINROT EDITION", 22, "#ff3df0", font=MEME_FONT)
        self._otext(W / 2, 330, "A / D  -  move", 20, "#ffffff")
        self._otext(W / 2, 362, "SPACE  -  jump  (double sigma jump in air)", 20, "#ffffff")
        self._otext(W / 2, 394, "stomp NPCs from above for max aura", 18, "#cfd8dc")
        self._otext(W / 2, 426, "P  -  pause     R  -  restart", 18, "#cfd8dc")
        self.menu_hint = self._otext(W / 2, 500, "PRESS  SPACE  TO  START", 26, "#76d275")
        self.canvas.tag_raise("hud")

    def _toggle_pause(self):
        if self.state == "play":
            self.state = "pause"
            self._clear_overlay()
            self._dim("gray50")
            self._otext(W / 2, H / 2 - 20, "PAUSED", 50, "#ffffff")
            self._otext(W / 2, H / 2 + 40, "press P to resume", 20, "#a8c0ff")
        elif self.state == "pause":
            self.state = "play"
            self._clear_overlay()

    def _game_over(self):
        self.state = "gameover"
        play_sfx(SFX["over"])
        self._clear_overlay()
        self._dim("gray75")
        self._otext(W / 2, 210, "GAME OVER", 60, "#ff4d6d", font=MEME_FONT)
        self._otext(W / 2, 268, random.choice(["skill issue tbh", "you got ohio'd",
                    "0 aura detected", "ratio'd by an NPC", "brokie run"]), 22, "#ff9aa8")
        self._otext(W / 2, 330, "Score: %d     Distance: %d m" % (self.score, int(self.kamera_x / 10)),
                    24, "#ffffff")
        self._otext(W / 2, 366, "Best combo: x%d" % self.best_combo, 20, "#a8c0ff")
        self._otext(W / 2, 440, "PRESS  R  TO  RESTART", 26, "#76d275")

    def _win(self):
        self.state = "win"
        play_sfx(SFX["win"])
        self.shake(10, 16)
        self._clear_overlay()
        self._dim("gray50")
        self._otext(W / 2, 200, "W RIZZ! VICTORY!", 60, "#ffd24a")
        self._otext(W / 2, 268, "you are the ohio final boss now", 22, "#ffffff")
        self._otext(W / 2, 320, "Final score: %d" % self.score, 26, "#76d275")
        self._otext(W / 2, 360, "Best combo: x%d" % self.best_combo, 20, "#a8c0ff")
        self._otext(W / 2, 440, "PRESS  R  TO  RUN  IT  BACK", 24, "#a8c0ff")

    def _key_down(self, e):
        k = e.keysym.lower()
        if k in self.keys:
            self.keys[k] = True

    def _key_up(self, e):
        k = e.keysym.lower()
        if k in self.keys:
            self.keys[k] = False

    def _press_space(self, e):
        if self.state == "menu":
            self.state = "play"
            self._clear_overlay()
            play_sfx(SFX["start"])
        elif self.state == "play":
            self.jump_buf = JUMP_BUFFER

    def _clear_fx(self):
        self.canvas.delete("fx")
        self.particles.clear()
        self.floaters.clear()

    def _respawn(self):
        self.kamera_x = float(self.last_checkpoint)
        self.vy = 0.0
        self.on_ground = False
        self.jumps_left = 0
        self.combo = 0
        self.combo_timer = 0
        self._clear_fx()
        self.canvas.coords(self.player, CENTER_X, GROUND_Y - 120)

    def _restart_all(self):
        if self.state not in ("gameover", "win"):
            return
        self.lives = MAX_LIVES
        self.score = 0
        self.combo = 0
        self.combo_timer = 0
        self.best_combo = 0
        self.last_checkpoint = 0.0
        self.kamera_x = 0.0
        self.vy = 0.0
        self.on_ground = False
        self._clear_fx()
        self.canvas.coords(self.player, CENTER_X, GROUND_Y - 39)
        self._clear_overlay()
        self._update_hud()
        self.state = "play"

    def _segment_at(self, world_x):
        for s, e in self.segments:
            if s <= world_x <= e:
                return (s, e)
        return None

    def _spawn_particles(self, sx, sy, color, n=8, spread=4, up=False):
        c = self.canvas
        for _ in range(n):
            vx = random.uniform(-spread, spread)
            vy = random.uniform(-spread, 0) if up else random.uniform(-spread, spread)
            pid = c.create_oval(sx - 4, sy - 4, sx + 4, sy + 4, fill=color, outline="", tags="fx")
            self.particles.append({"id": pid, "vx": vx, "vy": vy, "life": random.randint(14, 26)})

    def _update_particles(self):
        c = self.canvas
        dead = []
        for p in self.particles:
            p["vy"] += 0.25
            c.move(p["id"], p["vx"], p["vy"])
            p["life"] -= 1
            if p["life"] <= 0:
                dead.append(p)
        for p in dead:
            c.delete(p["id"])
            self.particles.remove(p)

    def float_text(self, x, y, text, color, size=22, dy=-1.4, life=42, jitter=14):
        x += random.randint(-jitter, jitter)
        tid = self.canvas.create_text(x, y, text=text, fill=color,
                                      font=(MEME_FONT, size), tags="fx")
        out = self.canvas.create_text(x, y, text=text, fill="#0a0c14",
                                      font=(MEME_FONT, size), tags="fx")
        self.canvas.tag_lower(out, tid)
        self.floaters.append({"id": tid, "shadow": out, "dy": dy, "life": life,
                              "max": life, "color": color})

    def _update_floaters(self):
        c = self.canvas
        dead = []
        for fl in self.floaters:
            c.move(fl["id"], 0, fl["dy"])
            c.move(fl["shadow"], 0, fl["dy"])
            fl["life"] -= 1
            if fl["life"] < fl["max"] * 0.35:
                c.itemconfig(fl["id"], fill="#7d8aa8")
            if fl["life"] <= 0:
                dead.append(fl)
        for fl in dead:
            c.delete(fl["id"])
            c.delete(fl["shadow"])
            self.floaters.remove(fl)

    def shake(self, mag, t):
        self.shake_mag = max(self.shake_mag, mag)
        self.shake_t = max(self.shake_t, t)

    def _apply_shake(self):
        c = self.canvas
        if self.shake_t > 0:
            f = self.shake_t / 12.0
            ox = random.uniform(-self.shake_mag, self.shake_mag) * f
            oy = random.uniform(-self.shake_mag, self.shake_mag) * f
            self.shake_t -= 1
        else:
            ox = oy = 0.0
            self.shake_mag = 0.0
        dx = ox - self.shake_applied[0]
        dy = oy - self.shake_applied[1]
        if dx or dy:
            c.move("all", dx, dy)
            self.shake_applied = [ox, oy]

    def add_combo(self):
        self.combo += 1
        self.combo_timer = COMBO_TIME
        self.best_combo = max(self.best_combo, self.combo)

    def _rank(self):
        for thr, name, col in RANKS:
            if self.combo >= thr:
                return name, col
        return None, None

    def _mult(self):
        return 1 + self.combo // 4

    def _apply_camera(self):
        c = self.canvas
        for layer in self.layers:
            target = -self.kamera_x * layer["factor"]
            delta = target - layer["applied"]
            if delta:
                c.move(layer["tag"], delta, 0)
                layer["applied"] = target

    def _animate_items(self):
        if self.tick % 5 != 0:
            return
        c = self.canvas
        for data in self.enemy_by_id.values():
            if data["frames"]:
                data["fi"] = (data["fi"] + 1) % len(data["frames"])
                c.itemconfig(data["id"], image=data["frames"][data["fi"]])
        if self.frames_onion:
            for cid, d in self.coin_by_id.items():
                if d["kind"] == "onion":
                    d["fi"] = (d["fi"] + 1) % len(self.frames_onion)
                    c.itemconfig(cid, image=self.frames_onion[d["fi"]])

    def _loop(self):
        self.tick += 1
        try:
            self._frame()
        except Exception:
            self._log_crash()
        self.root.after(16, self._loop)

    def _frame(self):
        if self.state == "menu":
            self.kamera_x += 0.6
            self._apply_camera()
            self._animate_items()
            self._animate_menu()
        elif self.state == "play":
            if self.hitstop > 0:
                self.hitstop -= 1
            else:
                self._step()
            self._apply_camera()
            self._animate_items()
            self._update_particles()
            self._update_floaters()
            self._tick_combo()
            self._ambient_taunt()
            self._update_hud()
        elif self.state == "dead":
            self._step_dead()
            self._update_particles()
            self._update_floaters()

        self._apply_shake()

    def _log_crash(self):
        self._crash_count = getattr(self, "_crash_count", 0) + 1
        if self._crash_count <= 30:
            try:
                import traceback
                with open("crash.log", "a", encoding="utf-8") as f:
                    f.write("tick %d state %s\n" % (self.tick, self.state))
                    f.write(traceback.format_exc() + "\n")
            except Exception:
                pass

    def _tick_combo(self):
        if self.combo_timer > 0:
            self.combo_timer -= 1
            if self.combo_timer == 0:
                self.combo = 0

    def _ambient_taunt(self):
        self.taunt_timer -= 1
        if self.taunt_timer <= 0:
            self.taunt_timer = random.randint(180, 340)
            self.float_text(random.randint(150, W - 150), random.randint(120, 260),
                            random.choice(MEME_TAUNT), "#c9d4f0", size=15, dy=-0.5,
                            life=70, jitter=0)

    def _animate_menu(self):
        if hasattr(self, "menu_hint"):
            self.canvas.itemconfig(self.menu_hint,
                                   fill="#76d275" if (self.tick // 18) % 2 == 0 else "#3a6b3a")
        if hasattr(self, "menu_sub"):
            self.canvas.itemconfig(self.menu_sub, text=random.choice(MEME_TAUNT).upper()
                                   if (self.tick % 60 == 0) else self.canvas.itemcget(self.menu_sub, "text"))

    def _step(self):
        c = self.canvas

        dx = 0
        if self.keys["a"]:
            dx -= MOVE_SPEED
            self.facing = -1
        if self.keys["d"]:
            dx += MOVE_SPEED
            self.facing = 1
        if dx and self.img_player_r:
            c.itemconfig(self.player, image=self.img_player_r if self.facing > 0 else self.img_player_l)

        if dx:
            world_x = CENTER_X + self.kamera_x
            target = world_x + dx
            blocked = False
            if self.on_ground:
                for s, e in self.segments:
                    if dx < 0 and world_x >= e and target < e:
                        blocked = True
                        break
                    if dx > 0 and world_x <= s and target > s:
                        blocked = True
                        break
            if not blocked:
                self.kamera_x += dx

        world_x = CENTER_X + self.kamera_x
        grounded_seg = self._segment_at(world_x) is not None

        if self.jump_buf > 0:
            if self.on_ground or self.coyote > 0:
                self.vy = JUMP_V
                self.jumps_left = 1
                self.on_ground = False
                self.coyote = 0
                self.jump_buf = 0
                py = c.coords(self.player)[1]
                self._spawn_particles(CENTER_X, py + 36, "#e8d9b5", 8, 3, up=True)
                play_sfx(SFX["jump"])
                if random.random() < 0.4:
                    self.float_text(CENTER_X, py - 30, random.choice(MEME_JUMP), "#ffffff", size=16)
            elif self.jumps_left > 0:
                self.vy = JUMP_V * 0.88
                self.jumps_left -= 1
                self.jump_buf = 0
                py = c.coords(self.player)[1]
                self._spawn_particles(CENTER_X, py + 36, "#a8c0ff", 10, 4)
                play_sfx(SFX["double"])
                self.float_text(CENTER_X, py - 30, random.choice(MEME_AIR), "#a8c0ff", size=16)

        self.vy += GRAVITY
        c.move(self.player, 0, self.vy)
        px, py = c.coords(self.player)
        bottom = py + 39

        landed = False
        if grounded_seg and self.vy >= 0 and bottom >= GROUND_Y and bottom - self.vy <= GROUND_Y + 14:
            c.move(self.player, 0, GROUND_Y - bottom)
            py = GROUND_Y - 39
            self.vy = 0
            if not self.on_ground:
                self._spawn_particles(CENTER_X, GROUND_Y, "#cdbb94", 7, 3)
            self.on_ground = True
            self.jumps_left = 2
            self.coyote = COYOTE
            landed = True
        else:
            if self.on_ground:
                self.coyote = COYOTE
            self.on_ground = False

        if self.coyote > 0 and not landed:
            self.coyote -= 1
        if self.jump_buf > 0:
            self.jump_buf -= 1

        air = max(0, GROUND_Y - (py + 39))
        sw = max(10, 28 - air * 0.05)
        c.coords(self.shadow, CENTER_X - sw, GROUND_Y + 6, CENTER_X + sw, GROUND_Y + 20)

        if py > H + 120:
            self._hit()
            return

        for data in self.enemy_by_id.values():
            data["wx"] += data["spd"]
            c.move(data["id"], data["spd"], 0)
            if abs(data["wx"] - data["home"]) >= data["range"]:
                data["spd"] = -data["spd"]
                data["wx"] += data["spd"]
                c.move(data["id"], data["spd"], 0)
            elif random.random() < 0.01:
                data["spd"] = random.choice([-5, -4, 4, 5]) * (1 if data["spd"] > 0 else -1)

        pb = c.bbox(self.player)
        if pb:
            hits = c.find_overlapping(pb[0] + 4, pb[1] + 4, pb[2] - 4, pb[3] - 4)
            for iid in hits:
                if iid in self.coin_by_id:
                    self._collect(iid)
                elif iid in self.enemy_by_id:
                    if self._resolve_enemy(iid, pb):
                        return

        if world_x >= WORLD_END - 250:
            self._win()
            return

        for cp in self.checkpoints:
            if cp <= world_x and cp > self.last_checkpoint:
                self.last_checkpoint = cp
                self._spawn_particles(CENTER_X, GROUND_Y - 60, "#76d275", 14, 5, up=True)
                play_sfx(SFX["checkpoint"])
                self.shake(5, 6)
                self.float_text(CENTER_X, GROUND_Y - 110, random.choice(MEME_CP), "#76d275", size=20)

    def _collect(self, iid):
        d = self.coin_by_id.pop(iid)
        self.canvas.delete(iid)
        self.add_combo()
        gain = d["value"] * self._mult()
        self.score += gain
        py = self.canvas.coords(self.player)[1]
        if d["kind"] == "coin":
            col = "#ffd24a"
            play_sfx(SFX["coin"])
            word = "+%d" % gain if random.random() < 0.6 else random.choice(MEME_COIN)
        else:
            col = "#b48cff"
            play_sfx(SFX["onion"])
            word = random.choice(MEME_COIN) + "!"
            self.shake(4, 6)
        self._spawn_particles(CENTER_X, py, col, 12, 5, up=True)
        self.float_text(CENTER_X, py - 24, word, col, size=18)

    def _resolve_enemy(self, iid, pb):
        data = self.enemy_by_id[iid]
        eb = self.canvas.bbox(iid)
        if not eb:
            return False
        stomp = self.vy > 0 and (pb[3] - eb[1]) < (eb[3] - eb[1]) * 0.6
        if stomp:
            data["hp"] -= 1
            self.vy = JUMP_V * 0.6
            self.hitstop = 3
            self.add_combo()
            py = self.canvas.coords(self.player)[1]
            if data["type"] == "boss":
                play_sfx(SFX["boss"])
                self.shake(12, 14)
                self._spawn_particles(CENTER_X, py, "#ff5252", 20, 7)
                self.float_text(CENTER_X, py - 30, "BOSS -1HP", "#ff5252", size=22)
            else:
                play_sfx(SFX["stomp"])
                self.shake(6, 8)
                self._spawn_particles(CENTER_X, py, "#ffffff", 14, 6)
                self.float_text(CENTER_X, py - 30, random.choice(MEME_STOMP),
                                "#ffd24a", size=20)
            if data["hp"] <= 0:
                self.canvas.delete(iid)
                del self.enemy_by_id[iid]
                gain = (10 if data["type"] == "boss" else 2) * self._mult()
                self.score += gain
                if data["type"] == "boss":
                    self._win()
                    return True
            return False
        else:
            self._hit()
            return True

    def _hit(self):
        self.lives -= 1
        self.combo = 0
        self.combo_timer = 0
        self._update_hud()
        play_sfx(SFX["hit"])
        self.shake(16, 18)
        self.state = "dead"
        self.dead_idx = 0
        self.dead_timer = 0
        self._clear_overlay()
        self._dim("gray50")
        if self.frames_dead:
            self.dead_img = self.canvas.create_image(W / 2, H / 2, image=self.frames_dead[0], tags="overlay")
        self._otext(W / 2, H / 2 + 130, random.choice(MEME_HIT), 44, "#ff4d6d")

    def _step_dead(self):
        self.dead_timer += 1
        if self.frames_dead and self.dead_timer % 4 == 0:
            self.dead_idx += 1
            if self.dead_idx < len(self.frames_dead):
                self.canvas.itemconfig(self.dead_img, image=self.frames_dead[self.dead_idx])
        if self.dead_timer >= 60:
            self._clear_overlay()
            if self.lives <= 0:
                self._game_over()
            else:
                self._respawn()
                self.state = "play"


if __name__ == "__main__":
    root = tk.Tk()
    Game(root)
    root.mainloop()
