import numpy as np
import wave
import os

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sfx")
os.makedirs(OUT, exist_ok=True)


def env(n, attack=0.005, decay=2.0):
    t = np.linspace(0, 1, n)
    a = np.clip(np.linspace(0, 1, max(1, int(n * attack))), 0, 1)
    e = np.exp(-t * decay)
    e[:len(a)] *= a
    e[-200:] *= np.linspace(1, 0, min(200, n))
    return e


def sweep(f0, f1, dur, kind="sine", curve="lin"):
    n = int(SR * dur)
    t = np.linspace(0, dur, n, endpoint=False)
    if curve == "exp":
        f = f0 * (f1 / f0) ** (t / dur)
    else:
        f = np.linspace(f0, f1, n)
    phase = 2 * np.pi * np.cumsum(f) / SR
    if kind == "sine":
        w = np.sin(phase)
    elif kind == "square":
        w = np.sign(np.sin(phase))
    elif kind == "saw":
        w = 2 * (phase / (2 * np.pi) - np.floor(0.5 + phase / (2 * np.pi)))
    else:
        w = np.sin(phase)
    return w


def tone(freq, dur, kind="sine"):
    return sweep(freq, freq, dur, kind)


def noise(dur):
    return np.random.uniform(-1, 1, int(SR * dur))


def save(name, data, gain=0.6):
    data = np.asarray(data, dtype=np.float64)
    m = np.max(np.abs(data)) or 1.0
    data = data / m * gain
    pcm = np.clip(data, -1, 1)
    pcm = (pcm * 32767).astype(np.int16)
    path = os.path.join(OUT, name)
    with wave.open(path, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print("wrote", name, "%.2fs" % (len(pcm) / SR))


def pad(a, b):
    n = max(len(a), len(b))
    return (np.pad(a, (0, n - len(a))), np.pad(b, (0, n - len(b))))


def mix(*arrs):
    n = max(len(a) for a in arrs)
    out = np.zeros(n)
    for a in arrs:
        out[:len(a)] += a
    return out


def seq(*parts):
    return np.concatenate(parts)


boom = sweep(160, 42, 0.55, "sine", "exp") * env(int(SR * 0.55), 0.001, 4.5)
punch = noise(0.04) * np.exp(-np.linspace(0, 1, int(SR * 0.04)) * 30) * 0.5
sub = sweep(90, 30, 0.55, "sine", "exp") * env(int(SR * 0.55), 0.001, 3.5) * 0.7
b1, b2 = pad(boom, sub)
save("vine_boom.wav", mix(b1, b2, np.pad(punch, (0, len(b1) - len(punch)))), 0.9)

thud = sweep(220, 70, 0.18, "sine", "exp") * env(int(SR * 0.18), 0.001, 6)
tp = noise(0.03) * np.exp(-np.linspace(0, 1, int(SR * 0.03)) * 40) * 0.4
save("stomp.wav", mix(thud, np.pad(tp, (0, len(thud) - len(tp)))), 0.8)

c1 = tone(988, 0.06, "square") * env(int(SR * 0.06), 0.002, 3)
c2 = tone(1319, 0.12, "square") * env(int(SR * 0.12), 0.002, 4)
save("coin.wav", seq(c1, c2), 0.45)

notes = [523, 659, 784, 1047]
pu = seq(*[tone(f, 0.08, "square") * env(int(SR * 0.08), 0.002, 3) for f in notes])
save("powerup.wav", pu, 0.45)

jmp = sweep(380, 760, 0.12, "sine") * env(int(SR * 0.12), 0.003, 5)
save("jump.wav", jmp, 0.5)

dj = sweep(760, 1500, 0.14, "square") * env(int(SR * 0.14), 0.003, 5)
save("double.wav", dj, 0.4)

ck = mix(tone(659, 0.18, "sine"), tone(988, 0.18, "sine")) * env(int(SR * 0.18), 0.003, 3)
save("checkpoint.wav", ck, 0.5)

wob = 1 + 0.04 * np.sin(np.linspace(0, 40, int(SR * 0.4)))
br = sweep(300, 120, 0.4, "saw", "exp") * env(int(SR * 0.4), 0.005, 2.5)
br = br * wob[:len(br)]
save("bruh.wav", br, 0.5)

fan = seq(
    tone(523, 0.12, "square") * env(int(SR * 0.12), 0.002, 2),
    tone(659, 0.12, "square") * env(int(SR * 0.12), 0.002, 2),
    tone(784, 0.12, "square") * env(int(SR * 0.12), 0.002, 2),
    tone(1047, 0.45, "square") * env(int(SR * 0.45), 0.002, 1.5),
)
save("win.wav", fan, 0.45)

over = seq(
    sweep(392, 370, 0.22, "saw") * env(int(SR * 0.22), 0.005, 1.8),
    sweep(330, 311, 0.22, "saw") * env(int(SR * 0.22), 0.005, 1.8),
    sweep(262, 196, 0.5, "saw", "exp") * env(int(SR * 0.5), 0.005, 1.5),
)
save("over.wav", over, 0.5)

st = sweep(523, 988, 0.16, "square") * env(int(SR * 0.16), 0.002, 3)
save("start.wav", st, 0.45)

print("DONE ->", OUT)
